from .utils import Neo4j
import polars as pl 
import pandas as pd 
import numpy as np 
import country_converter as cc

class AuthorLocations(Neo4j):
    """Country codes from authors' affiliations."""

    def __init__(self, cypher_query=None, lookup=None):
        super().__init__(cypher_query, lookup)

        self.author_locations = {}
        self._author_ids = {}

        uri = 's3://datalabs-data/dimensions/organisations/organisation_addresses.parquet'
        self.institution_addresses = pl.read_parquet(uri).to_pandas().set_index('id')['country_code'].to_dict()

    def from_publication_ids(self, publication_ids):
        """Initialise author grid IDs with publications
        from Dimensions IDs and their authors.
        
        Args:
            publication_ids(list): List of Dimnsions IDs.
        """


        query = """
            MATCH (r:Researcher)-[a:AUTHORED]->(p:Publication)
            WHERE p.dimensions_publication_id IN {} 
            RETURN r.dimensions_researcher_id, id(r), a.institutions, a.position, p.dimensions_publication_id, p.year
            """
        
        return self.lookup_query(query=query, lookup=publication_ids, as_graph=False)
    
    def get_institution(self, institution_id):
        """Get institution from ID."""

        if not pd.isna(institution_id):
            try:
                return self.institution_addresses[institution_id]
            except:
                return ''
        else:
            return ''

    def add_author_locations(self):
        """Add author locations from parquet."""

        self.dataframe = pd.DataFrame(self.data)
        self.dataframe = self.dataframe.explode('a.institutions')
        # .dropna(subset=['a.institutions'])

        self.dataframe['country_code'] = self.dataframe['a.institutions'].apply(lambda x: self.get_institution(x))

        return self.dataframe