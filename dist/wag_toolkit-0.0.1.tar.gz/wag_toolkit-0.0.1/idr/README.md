# Wellcome Academic Graph Toolkit - IDR

## Description

This is the Interdisciplinary module of the Wellcome Academic Graph Toolkit. It makes use of the IDR class imported from the Wellcome Academic Graph Toolkit for an analysis of Discovery Researchers Portfolio (full technical results can be found [here](https://wellcomecloud.sharepoint.com/:w:/r/sites/Grp_Data_DataDigital/_layouts/15/Doc.aspx?sourcedoc=%7B108ED5C2-27CF-43B9-89BC-B98038F87499%7D&file=Narrative%20Report%20Draft.docx&action=default&mobileredirect=true)).

## Installation

Provide instructions on how to install the module.

## Usage

Provide instructions on how to use the module.

## Contributing

Provide instructions on how to contribute to the project.

## License

Specify the license for the project.
