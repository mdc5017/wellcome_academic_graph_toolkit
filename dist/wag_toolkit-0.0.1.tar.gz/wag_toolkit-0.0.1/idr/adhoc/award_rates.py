from wag_toolkit.utils import read_from_s3
from wag_toolkit.utils import Neo4j
from currency_converter import CurrencyConverter
from datetime import date
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns 

S3_OUTPUT_FOLDER = 'funding_impact_measures/idr/dr'
teams = read_from_s3(S3_OUTPUT_FOLDER + "/grantees_fields.csv")
teams = teams[teams["no_pubs"] >= 20]

teams['year'] = teams['g.start_date'].apply(lambda x: int(x[:4]))
teams['date'] = teams['g.start_date'].apply(lambda x: date(int(x[:4]), int(x[5:7]), int(x[8:10])))
teams.sort_values(by='year', ascending=False, inplace=True)

researchers_per_grant = teams.groupby(['id(g)', 'year']).size()

proportion_1_researcher = researchers_per_grant[researchers_per_grant == 1].groupby('year').size()  / researchers_per_grant.groupby('year').size()
proportion_more_than_1_researcher = researchers_per_grant[researchers_per_grant > 1].groupby('year').size() / researchers_per_grant.groupby('year').size()

df = pd.DataFrame([proportion_1_researcher, proportion_more_than_1_researcher]).T
df.columns = ['1 Researcher', 'More than 1 Researcher']

plt.figure(figsize=(10, 6))
df.plot(kind='bar', stacked=True)
plt.xlabel('Year')
plt.ylabel('Number of Grants')
plt.title('Number of Grants with 1 Researcher vs More than 1 Researcher')
plt.legend(loc='lower left')
plt.savefig('idr/adhoc/outputs/award_rates_prop.png', bbox_inches='tight')

top_decile = teams['rs_cosine'].quantile(0.75)
teams['top_decile'] = teams.apply(lambda x: 1 if x.rs_cosine >= top_decile else 0, axis=1)
teams = teams[teams['year'] != 2023]

idx_plus_one = list(researchers_per_grant[researchers_per_grant > 1].index)
teams_plus_one = [i[0] for i in idx_plus_one]

teams_plus_one = teams[teams['id(g)'].isin(teams_plus_one)]
teams_plus_one[['rs_cosine', 'id(g)', 'year']].groupby(['id(g)', 'year']).mean()

average_rs_cosine = teams_plus_one.groupby('year')['top_decile'].sum()/teams_plus_one.groupby('year').size()
counter_per_year = teams_plus_one.groupby('year').size()

fig, ax1 = plt.subplots(figsize=(10, 6))

# Line chart for average rs_cosine per year
smoothed_data = average_rs_cosine.rolling(window=3, min_periods=1).mean()
std_dev = average_rs_cosine.rolling(window=4, min_periods=1).std()
ax1.plot(average_rs_cosine.index, smoothed_data, color='blue')
ax1.fill_between(average_rs_cosine.index, smoothed_data - std_dev, smoothed_data + std_dev, alpha=0.2)
# ax1.plot(average_rs_cosine.index, average_rs_cosine.values, color='blue')
ax1.set_xlabel('Year')
ax1.set_ylabel('Proportiom of Researchers in Top Quartile of Diversity')
ax1.set_title('Researcher Diversity for Team-based Awards')

# Bar chart for counter per year
ax2 = ax1.twinx()
ax2.bar(counter_per_year.index, counter_per_year.values, alpha=0.5, color='orange')
ax2.set_ylabel('Number of Researchers')
plt.savefig('idr/adhoc/outputs/team_idr_quartiles.png', bbox_inches='tight')
