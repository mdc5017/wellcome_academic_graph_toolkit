from idr.utils import get_ids
from wag_toolkit.diversity import IDR
import pandas as pd 
from datetime import date

path = "funding_impact_measures/dr_grants/dr_pub_grant_links.xlsx"
grant_ids, pub_ids = get_ids(fname=path)

idr = IDR()
grant_fors = idr.get_grant_field(grant_ids).data
grant_df = pd.DataFrame(grant_fors)
grant_df['g.for'] = grant_df['g.for'].apply(lambda x: [x])

grant_df = idr.query_to_diversity( grant_df, for_col="g.for")
grant_df['fields'] = grant_df['super_group_counts'].apply(lambda x: [i[0] for i in x])
grant_df['year'] = grant_df['g.start_date'].apply(lambda x: int(x[:4]))

sub = ['HUMANITIES', 'SOCIAL SCIENCE', 'HEALTH SCIENCES', 'CLINICAL SCIENCES']
groups = pd.read_csv('idr/input/anzsrc2020.csv')
mapping = {}
for field in sub:
    super_group = list(groups[groups['dr_super_group'] == field].super_group.unique())
    mapping[field] = super_group

def grant_has_field(row, field):
    super_group =  mapping[field]
    super_group = [group.title() for group in super_group]
    if set(super_group).intersection(set(row)) != set():
        return 1
    return 0

grant_df = grant_df[grant_df['year'] != 2023]
researchers = grant_df[['year', 'fields']]
total = grant_df.groupby('year').size()

fig, ax = plt.subplots()
fig.set_size_inches(10, 6)
all_fields = []
for field in sub:
    researchers['in_field'] = researchers['fields'].apply(lambda x: grant_has_field(x, field))
    researchers_over_time = researchers[researchers['in_field'] == 1].groupby('year').size()
    all_fields.append(researchers_over_time)

    sub_total = total[total.index.isin(researchers_over_time.index)]
    import numpy as np

    # Calculate mean and standard deviation of researchers_over_time
    mean = researchers_over_time.values / sub_total
    std = np.sqrt(researchers_over_time.values) / sub_total

    smoothed_data = researchers_over_time.values.rolling(window=3, min_periods=1).mean()
    std_dev = researchers_over_time.values.rolling(window=4, min_periods=1).std()
    ax.plot(researchers_over_time.values.index, smoothed_data, label=field)
    ax.fill_between(researchers_over_time.values.index, smoothed_data - std_dev, smoothed_data + std_dev, alpha=0.2)


ax.legend()
ax.set_ylabel('Proportion of Grants')

all_fields_df = pd.concat(all_fields, axis=1)
all_fields_df.columns = sub
all_fields_df.sort_index(inplace=True)

ax1 = ax.twinx() 
x = all_fields_df.index  # the label locations
width = 0.25  # the width of the bars
multiplier = 0
for attribute, measurement in all_fields_df.items():
    offset = width * multiplier
    rects = ax1.bar(x + offset, measurement, width, label=attribute, alpha=0.5)
    multiplier += 1

ax1.set_ylabel('Absolute Grant Counts')
plt.xlabel('Year')
plt.title(f'Grants with Field Tag')
plt.savefig('idr/adhoc/outputs/grant_fields.png', bbox_inches='tight')