import matplotlib.pyplot as plt
import seaborn as sns
from wag_toolkit.utils import read_from_s3

S3_OUTPUT_FOLDER = 'funding_impact_measures/idr/dr'
teams = read_from_s3(S3_OUTPUT_FOLDER + "/grantees_field_bygrant.csv")
outputs = read_from_s3(S3_OUTPUT_FOLDER + "/knowledge_integration_bygrant.csv")
impact = read_from_s3(S3_OUTPUT_FOLDER + "/knowledge_diffusion_bygrant.csv")

# TEAMS
teams['start_year'] = teams['g.start_date'].apply(lambda x: int(x[:4]))
mean = teams['team_diversity'].mean()
teams['above_mean'] = teams.apply(lambda x: 1 if x.team_diversity >= mean else 0, axis=1)

teams[['start_year', 'above_mean']].value_counts().sort_index().unstack().plot(kind='bar')
plt.title('Number of grants with higher than average team diversity by year')
plt.xlabel('Year')
plt.ylabel('Number of grants')
plt.legend(['Below mean', 'Above mean'])
plt.savefig('idr/adhoc/outputs/number_of_grants_by_year.png', bbox_inches='tight')

teams['start_year'] = teams['g.start_date'].apply(lambda x: int(x[:4]))
top_decile = teams['team_diversity'].quantile(0.75)
teams['top_decile'] = teams.apply(lambda x: 1 if x.team_diversity >= top_decile else 0, axis=1)
teams = teams[teams['start_year'] != 2023]
teams[['start_year', 'top_decile']].value_counts().sort_index().unstack().div(teams[['start_year', 'top_decile']].value_counts().sort_index().unstack().sum(axis=1), axis=0).plot(kind='bar', stacked=True)
plt.title('Proportion of grants with team diversity in the top quartile')
plt.xlabel('Year')
plt.ylabel('Proportion of grants')
plt.legend(['Not in top quartile', 'In top quartile'], loc='lower left')
plt.savefig('idr/adhoc/outputs/team_diversity_proportion_of_grants_in_top_quartile_by_year.png', bbox_inches='tight')

# OUTPUTS
outputs['start_year'] = outputs['g.start_date'].apply(lambda x: int(x[:4]))
top_decile = outputs['output_diversity'].quantile(0.75)
outputs = outputs[outputs['start_year'] != 2023]
outputs['top_quartile'] = outputs.apply(lambda x: 1 if x.output_diversity >= top_decile else 0, axis=1)
outputs[['start_year', 'top_quartile']].value_counts().sort_index().unstack().div(outputs[['start_year', 'top_quartile']].value_counts().sort_index().unstack().sum(axis=1), axis=0).plot(kind='bar', stacked=True)
plt.title('Proportion of grants with output diversity in the top decile')
plt.xlabel('Year')
plt.ylabel('Proportion of grants')
plt.legend(['Not in top quartile', 'In top quartile'], loc='lower left')
plt.savefig('idr/adhoc/outputs/output_diversity_proportion_of_grants_in_top_quartile_by_year.png', bbox_inches='tight')

# IMPACT
impact['start_year'] = impact['g.start_date'].apply(lambda x: int(x[:4]))
top_decile = impact['impact_diversity'].quantile(0.9)
impact['top_decile'] = impact.apply(lambda x: 1 if x.impact_diversity >= top_decile else 0, axis=1)
impact[['start_year', 'top_decile']].value_counts().sort_index().unstack().div(impact[['start_year', 'top_decile']].value_counts().sort_index().unstack().sum(axis=1), axis=0).plot(kind='bar', stacked=True)
plt.title('Proportion of grants with impact diversity in the top decile')
plt.xlabel('Year')
plt.ylabel('Proportion of grants')
plt.legend(['Not in top decile', 'In top decile'])
plt.savefig('idr/adhoc/outputs/impact_diversity_proportion_of_grants_in_top_decile_by_year.png', bbox_inches='tight')