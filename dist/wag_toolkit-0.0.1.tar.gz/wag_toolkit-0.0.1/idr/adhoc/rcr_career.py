from wag_toolkit.utils import read_from_s3
from wag_toolkit.utils import Neo4j
from datetime import date
import pandas as pd
import numpy as np
from datetime import datetime
from datetime import datetime
from pandas import Timestamp
import numpy as np
import matplotlib.pyplot as plt

S3_OUTPUT_FOLDER = 'funding_impact_measures/idr/dr'
teams = read_from_s3(S3_OUTPUT_FOLDER + "/grantees_fields.csv")
teams = teams[teams["no_pubs"] >= 20]

teams['year'] = teams['g.start_date'].apply(lambda x: int(x[:4]))
teams['date'] = teams['g.start_date'].apply(lambda x: date(int(x[:4]), int(x[5:7]), int(x[8:10])))
teams.sort_values(by='year', ascending=True, inplace=True)
teams = teams.drop_duplicates('id(r)')

top_decile = teams['rs_cosine'].quantile(0.75)
bottom_decile = teams['rs_cosine'].quantile(0.1)
teams['top_decile'] = teams.apply(lambda x: 1 if x.rs_cosine >= top_decile else 0, axis=1)
teams['bottom_decile'] = teams.apply(lambda x: 1 if x.rs_cosine <= bottom_decile else 0, axis=1)

S3_OUTPUT_FOLDER = 'dimensions/careers/exploded_career_data/researchers_exploded.csv'
rcr = read_from_s3(S3_OUTPUT_FOLDER)

def drop_duplicate_pubs(row):
    pubs = []
    times = []
    rcrs = []
    for i, (pub, time, rcr_bool, rcr) in enumerate(zip( eval(row['dimensions_publication_id']), eval(row['date']), eval(row['RCR_log_above_threshold']), np.fromstring(row['RCR_log'].strip("[]"), sep=','))):
        if pub not in pubs:
            pubs.append(pub)
            times.append(time)
            if np.isnan(rcr):
                rcrs.append(np.nan)
            else:
                rcrs.append(rcr_bool)
    return pubs, times, rcrs

rcr['pubs'], rcr['pub_date'], rcr['rcrs_threshold'] = zip(*rcr.apply(lambda x: drop_duplicate_pubs(x), axis=1))

researchers = list(teams['id(r)'].unique())
query = f"""
        MATCH (r:Researcher)
        WHERE id(r) IN {researchers}
        RETURN id(r), r.dimensions_researcher_id
        """
neo = Neo4j()
neo.query(query, as_graph=False)
r_ids = neo.data
r_ids = pd.DataFrame(r_ids)

sub_teams = teams[['top_decile', 'id(r)', 'date']].merge(r_ids, left_on='id(r)', right_on='id(r)', how='left')
# teams_rcr = sub_teams.merge(rcr[['dimensions_researcher_id', 'RCR_log_above_threshold', 'date']], left_on='r.dimensions_researcher_id', right_on='dimensions_researcher_id', how='left')
teams_rcr = sub_teams.merge(rcr[['dimensions_researcher_id', 'rcrs_threshold', 'pub_date']], left_on='r.dimensions_researcher_id', right_on='dimensions_researcher_id', how='left')

# def publications_post_grant(row):
#     before_grant = []
#     after_grant = []
#     pub_dates = eval(row['date_y'])
#     rcr_bool = eval(row['RCR_log_above_threshold'])
#     for i, date in enumerate(pub_dates):
#         if date < Timestamp(row['date_x']):
#             print (date, Timestamp(row['date_x']))
#             before_grant.append(rcr_bool[i])
#         else:
#             after_grant.append(rcr_bool[i])
#     return before_grant, after_grant

def publications_post_grant(row):
    before_grant = []
    after_grant = []
    pub_dates = row['pub_date']
    rcr_bool = row['rcrs_threshold']
    for i, date in enumerate(pub_dates):
        if date < Timestamp(row['date']):
            print (date, Timestamp(row['date']))
            before_grant.append(rcr_bool[i])
        else:
            after_grant.append(rcr_bool[i])
    return before_grant, after_grant

teams_rcr['grants']= teams_rcr.apply(lambda x: publications_post_grant(x), axis=1)
teams_rcr['before_grant'] = teams_rcr['grants'].apply(lambda x: x[0])
teams_rcr['after_grant'] = teams_rcr['grants'].apply(lambda x: x[1])

teams_rcr['total_before_grant'] = teams_rcr['before_grant'].apply(lambda x: len(x))
teams_rcr['total_after_grant'] = teams_rcr['after_grant'].apply(lambda x: len(x))

# teams_rcr['total_before_grant_nonna'] = teams_rcr['before_grant'].apply(lambda x: len([i for i in x if not np.isnan(i)]))
# teams_rcr['total_after_grant_nonna'] = teams_rcr['after_grant'].apply(lambda x: len([i for i in x if not np.isnan(i)]))

# teams_rcr['one_above_threshold_before_grant'] = teams_rcr['before_grant'].apply(lambda x: 1 if any([i for i in x if not np.isnan(i)]) else 0)
# teams_rcr['one_above_threshold_after_grant'] = teams_rcr['after_grant'].apply(lambda x: 1 if any([i for i in x if not np.isnan(i)]) else 0)

# top_decile_researchers = teams_rcr[teams_rcr['id(r)'].isin(teams[teams['top_decile'] == 1]['id(r)'])]
# top_prop_one_above_threshold_before_grant = top_decile_researchers['one_above_threshold_before_grant'].sum()/len(top_decile_researchers)
# top_prop_one_above_threshold_after_grant = top_decile_researchers['one_above_threshold_after_grant'].sum()/len(top_decile_researchers)

# other_decile_researchers = teams_rcr[teams_rcr['id(r)'].isin(teams[teams['top_decile'] == 0]['id(r)'])]
# other_prop_one_above_threshold_before_grant = other_decile_researchers['one_above_threshold_before_grant'].sum()/len(other_decile_researchers)
# other_prop_one_above_threshold_after_grant = other_decile_researchers['one_above_threshold_after_grant'].sum()/len(other_decile_researchers)

# # PLOTS
# labels = ['Top Quartile', 'Other Quartiles']
# avg_proportion_top = [top_prop_one_above_threshold_before_grant, top_prop_one_above_threshold_after_grant]
# avg_proportion_other = [other_prop_one_above_threshold_before_grant, other_prop_one_above_threshold_after_grant]

# df = pd.DataFrame([avg_proportion_top, avg_proportion_other])
# df.columns = ['before', 'after']

# fig, ax1 = plt.subplots()
# x = df.index
# width = 0.25 
# multiplier = 0
# for attribute, measurement in df.items():
#     offset = width * multiplier
#     rects = ax1.bar(x + offset, measurement, width, label=attribute, alpha=0.5)
#     multiplier += 1

# plt.legend()
# ax1.set_xticks(x)
# ax1.set_xticklabels(labels)
# plt.ylabel('Proportion >= 1 Publication Exceeding 95th Percentile')
# plt.title('Researchers Exceeding 95th Percentile')
# plt.show()


# plt.savefig('idr/adhoc/outputs/researchers_exceeding_threshold.png', bbox_inches='tight')

# Point plot for average amounts
# ax1.plot(labels, avg_total,  'ro-', linestyle=' ')
# ax1.set_xlabel('Decile')
# ax1.set_ylabel('Median Publications Exceeding 95th Percentile')
# ax1.bar(labels, avg_proportion_top, alpha=0.25)
# ax1.set_ylabel('Proportion >= 1 Publication Exceeding 95th Percentile')

# ax2 = ax1.twinx()
# ax2.bar(labels, avg_proportion, alpha=0.25)
# ax2.set_ylabel('Proportion >= 1 Publication Exceeding 95th Percentile')

# # Set title and legend
# ax1.set_title('Research Publications Exceeding 95th Percentile')
# ax1.legend(loc='upper left')
# ax2.legend(loc='upper right')
# ax1.legend(['Median Exceeding Pubs'], loc='upper left')
# ax2.legend(['Prop >= 1'], loc='upper right')
# ax2.set_ylim((0,1))
# ax1.set_ylim((5,9))
# plt.savefig('idr/adhoc/outputs/researchers_excedding_threshold.png', bbox_inches='tight')

teams_rcr['total_above_threshold_before_grant'] = teams_rcr['before_grant'].apply(lambda x: sum([i for i in x if not np.isnan(i)]))
teams_rcr['total_above_threshold_after_grant'] = teams_rcr['after_grant'].apply(lambda x:  sum([i for i in x if not np.isnan(i)]))

teams_rcr['total_before_grant_nonna'] = teams_rcr['before_grant'].apply(lambda x: len([i for i in x if not np.isnan(i)]))
teams_rcr['total_after_grant_nonna'] = teams_rcr['after_grant'].apply(lambda x: len([i for i in x if not np.isnan(i)]))

top_decile_researchers = teams_rcr[teams_rcr['id(r)'].isin(teams[teams['top_decile'] == 1]['id(r)'])]
top_prop_total_above_threshold_before_grant = top_decile_researchers['total_above_threshold_before_grant'].sum()/teams_rcr['total_before_grant_nonna'].sum()
top_prop_total_above_threshold_after_grant = top_decile_researchers['total_above_threshold_after_grant'].sum()/teams_rcr['total_after_grant_nonna'].sum()

other_decile_researchers = teams_rcr[teams_rcr['id(r)'].isin(teams[teams['top_decile'] == 0]['id(r)'])]
other_prop_total_above_threshold_before_grant = other_decile_researchers['total_above_threshold_before_grant'].sum()/teams_rcr['total_before_grant_nonna'].sum()
other_prop_total_above_threshold_after_grant = other_decile_researchers['total_above_threshold_after_grant'].sum()/teams_rcr['total_after_grant_nonna'].sum()


import matplotlib.pyplot as plt

# Plotting the statistics
labels = ['Top Quartile', 'Other Quartiles']
avg_proportion_top = [top_prop_total_above_threshold_before_grant, top_prop_total_above_threshold_after_grant]
avg_proportion_other = [other_prop_total_above_threshold_before_grant, other_prop_total_above_threshold_after_grant]

df = pd.DataFrame([avg_proportion_top, avg_proportion_other])
df.columns = ['before', 'after']

fig, ax1 = plt.subplots()
x = df.index
width = 0.25 
multiplier = 0
for attribute, measurement in df.items():
    offset = width * multiplier
    rects = ax1.bar(x + offset, measurement, width, label=attribute, alpha=0.5)
    multiplier += 1

plt.legend()
ax1.set_xticks(x)
ax1.set_xticklabels(labels)
plt.ylabel('Proportion of all publications exceeding 95th percentile')
plt.title('Publications Exceeding 95th Percentile')
plt.show()

plt.savefig('idr/adhoc/outputs/publications_exceeding_threshold.png', bbox_inches='tight')