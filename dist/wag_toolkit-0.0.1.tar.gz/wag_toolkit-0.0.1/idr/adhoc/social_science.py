from wag_toolkit.utils import read_from_s3
from wag_toolkit.utils import Neo4j
from currency_converter import CurrencyConverter
from datetime import date
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns 

S3_OUTPUT_FOLDER = 'funding_impact_measures/idr/dr'
teams = read_from_s3(S3_OUTPUT_FOLDER + "/grantees_fields.csv")
teams = teams[teams["no_pubs"] >= 20]

teams['year'] = teams['g.start_date'].apply(lambda x: int(x[:4]))
teams['date'] = teams['g.start_date'].apply(lambda x: date(int(x[:4]), int(x[5:7]), int(x[8:10])))
teams.sort_values(by='year', ascending=False, inplace=True)
teams = teams.drop_duplicates('id(r)')

sub = ['HUMANITIES', 'SOCIAL SCIENCE', 'HEALTH SCIENCES', 'CLINICAL SCIENCES']
groups = pd.read_csv('idr/input/anzsrc2020.csv')
mapping = {}
for field in sub:
    super_group = list(groups[groups['dr_super_group'] == field].super_group.unique())
    mapping[field] = super_group

mean = teams['rs_cosine'].mean()
teams['top_field'] = teams.apply(lambda x: [eval(x.top_supergroups)[0]] if x.rs_cosine < mean else list(eval(x.top_supergroups)), axis=1)

teams = teams[teams['year'] != 2023]

researchers = teams[['year', 'top_field']].explode('top_field')
total = teams.groupby('year').size()

#  PLOT 
fig, ax = plt.subplots()
fig.set_size_inches(8, 8)
all_fields = []
for field in sub:
    researchers_by_field = []
    super_group =  mapping[field]
    super_group = [group.title() for group in super_group]
    researchers_over_time = researchers[researchers['top_field'].isin(super_group)].groupby('year').size()
    researchers_by_field.append(researchers_over_time)
    all_fields.append(pd.concat(researchers_by_field))
    researchers_by_field = pd.DataFrame(pd.concat(researchers_by_field))
    researchers_by_field.columns = ['counts']

    researchers_by_field['year'] = researchers_by_field.index
    researchers_by_field.reset_index(drop=True, inplace=True)

    sub_total = total[total.index.isin(researchers_by_field['year'].unique())]
    researchers_by_field['prop'] = researchers_by_field['counts'].values/sub_total.values
    # Smooth line plot

    smoothed_data = researchers_by_field['prop'].rolling(window=3, min_periods=1).mean()
    std_dev = researchers_by_field['prop'].rolling(window=4, min_periods=1).std()
    ax.plot(researchers_by_field['year'], smoothed_data, label=field)
    ax.fill_between(researchers_by_field['year'], smoothed_data - std_dev, smoothed_data + std_dev, alpha=0.2)

ax.legend()
ax.set_ylabel('Proportion of Researchers')
all_fields_df = pd.concat(all_fields, axis=1)
all_fields_df.columns = sub
all_fields_df.sort_index(inplace=True)

ax1 = ax.twinx() 
x = all_fields_df.index  # the label locations
width = 0.25  # the width of the bars
multiplier = 0
for attribute, measurement in all_fields_df.items():
    offset = width * multiplier
    rects = ax1.bar(x + offset, measurement, width, label=attribute, alpha=0.5)
    multiplier += 1

ax1.set_ylabel('Absolute Researcher Counts')
plt.title(f'Researchers with Field as Top (or Second) Field over Time')
plt.savefig('idr/adhoc/outputs/researchers_with_field_as_top_or_second_field_over_time.png', bbox_inches='tight')


# fig, ax = plt.subplots()
# researchers_by_field = researchers.groupby(['year', 'top_field']).size().unstack()
# researchers_by_field = researchers_by_field.div(researchers_by_field.sum(axis=1), axis=0)
# researchers_by_field.plot(kind='bar', stacked=True, ax=ax)

# plt.xlabel('Date')
# plt.ylabel('Proportion of Researchers')
# plt.title('Proportion of Researchers from Each Field over Time')
# plt.legend(title='Field')
# plt.savefig('idr/adhoc/outputs/proportion_of_researchers_from_each_field_over_time.png', bbox_inches='tight')
