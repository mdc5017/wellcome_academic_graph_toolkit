from wag_toolkit.utils import read_from_s3
from wag_toolkit.utils import Neo4j
from currency_converter import CurrencyConverter
from datetime import date
import pandas as pd

S3_OUTPUT_FOLDER = 'funding_impact_measures/idr/dr'
teams = read_from_s3(S3_OUTPUT_FOLDER + "/grantees_fields.csv")
teams = teams[teams["no_pubs"] >= 20]

teams['year'] = teams['g.start_date'].apply(lambda x: int(x[:4]))
teams['date'] = teams['g.start_date'].apply(lambda x: date(int(x[:4]), int(x[5:7]), int(x[8:10])))
teams.sort_values(by='year', ascending=False, inplace=True)
teams = teams.drop_duplicates('id(r)')

top_decile = teams['rs_cosine'].quantile(0.75)
bottom_decile = teams['rs_cosine'].quantile(0.1)
teams['top_decile'] = teams.apply(lambda x: 1 if x.rs_cosine >= top_decile else 0, axis=1)
teams['bottom_decile'] = teams.apply(lambda x: 1 if x.rs_cosine <= bottom_decile else 0, axis=1)

researchers = list(teams['id(r)'].unique())
dates = list(teams['date'].unique())
query  = f"""
        MATCH (g:Grant)-[a:AWARDED_TO]->(r:Researcher)
        WHERE id(r) IN {researchers}
        RETURN id(g), g.dimensions_grant_id, g.original_source_id, g.start_date, g.funding_amount, g.funding_currency, id(r), r.first_name, r.last_name
        """

neo = Neo4j()
neo.query(query, as_graph=False)
future_grants = neo.data
future_grants = pd.DataFrame(future_grants)

# get only grants after the first Wellcome funded grant
future_grants['date'] = future_grants['g.start_date'].apply(lambda x: date(int(x[:4]), int(x[5:7]), int(x[8:10])) if x is not None else np.nan)

post_wellcome_grants = []
for researcher, wellcome_date in zip(researchers, dates):
    sub = future_grants[future_grants['id(r)'] == researcher]
    sub = sub[sub['date'] >= wellcome_date]
    post_wellcome_grants.append(sub)

future_grants = pd.concat(post_wellcome_grants)

# Currency conversion
c = CurrencyConverter()
converted = []
for i, item in future_grants.iterrows():
    try:
        exchange = c.convert(item['g.funding_amount'], 'GBP', item['g.funding_currency'], date(int(item['g.start_date'][:4]), 
                                                                                           int(item['g.start_date'][5:7]), 
                                                                                           int(item['g.start_date'][8:10])
                                                                                           ))
        converted.append(exchange)
    except:
        converted.append(np.nan)

future_grants['converted_amount'] = converted
future_grants['grant_amounts'] = future_grants.apply(lambda x: x['g.funding_amount'] if x['g.funding_currency'] == 'GBP' else x.converted_amount, axis=1)

# Calculate average number of grants per researcher for the top decile
top_decile_grants = future_grants[future_grants['id(r)'].isin(teams[teams['top_decile'] == 1]['id(r)'])]
top_decile_avg_grants = top_decile_grants.groupby('id(r)').size().mean()

# Calculate average number of grants per researcher for the bottom decile
bottom_decile_grants = future_grants[future_grants['id(r)'].isin(teams[teams['top_decile'] == 0]['id(r)'])]
bottom_decile_avg_grants = bottom_decile_grants.groupby('id(r)').size().mean()

# Calculate average amount of grants per researcher for the top decile
top_decile_avg_amount = top_decile_grants.groupby('id(r)')['grant_amounts'].mean().median()

# Calculate average amount of grants per researcher for the bottom decile
bottom_decile_avg_amount = bottom_decile_grants.groupby('id(r)')['grant_amounts'].mean().mean()

import matplotlib.pyplot as plt

# Plotting the statistics
labels = ['Top Quartile', 'Other Quartiles']
avg_grants = [top_decile_avg_grants, bottom_decile_avg_grants]
avg_amounts = [top_decile_avg_amount, bottom_decile_avg_amount]

fig, ax1 = plt.subplots()

# Point plot for average amounts
ax1.plot(labels, avg_grants,  'ro-', linestyle=' ')
ax1.set_xlabel('Decile')
ax1.set_ylabel('Number of Grants')

ax2 = ax1.twinx()
ax2.bar(labels, avg_amounts, alpha=0.25)
ax2.set_ylabel('Average Grant Amount')

# Set title and legend
ax1.set_title('Comparison of Number of Grants and Award Amounts per Researcher')
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
ax1.set_ylim(0, 6)
ax1.legend(['Number of Grants'], loc='upper left')
ax2.legend(['Average Grant Amount'], loc='upper right')
plt.savefig('idr/adhoc/outputs/number_of_grants_and_award_amounts_per_researcher_quartile.png', bbox_inches='tight')
