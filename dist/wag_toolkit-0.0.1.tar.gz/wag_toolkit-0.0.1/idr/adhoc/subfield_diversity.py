import plotly.express as px
import pandas as pd
from idr.vis import sub_fields
from wag_toolkit.utils import read_from_s3

S3_OUTPUT_FOLDER = 'funding_impact_measures/idr/dr'
outputs = sub_fields(S3_OUTPUT_FOLDER)
outputs = outputs[outputs["no_refs"] >= 8]
outputs_bygrant = read_from_s3(S3_OUTPUT_FOLDER + "/knowledge_integration_bygrant.csv")

outputs = outputs_bygrant[['grant_id', 'g.start_date']].merge(outputs)

outputs['start_year'] = outputs['g.start_date'].apply(lambda x: int(x[:4]))
top_decile = outputs['rs_cosine'].quantile(0.75)
outputs['top_quartile'] = outputs.apply(lambda x: 1 if x.rs_cosine >= top_decile else 0, axis=1)

df = outputs[['start_year', 'top_quartile', 'sub_fields']].explode('sub_fields').groupby(['sub_fields', 'start_year']).sum() / outputs[['start_year', 'top_quartile', 'sub_fields']].explode('sub_fields').groupby(['sub_fields', 'start_year']).count()
df['counts'] = outputs[['start_year', 'top_quartile', 'sub_fields']].explode('sub_fields').groupby(['sub_fields', 'start_year']).count()
df['year'] = df.index.get_level_values(1)
df['subfield'] = df.index.get_level_values(0)

fig = px.line(df, x="year", y="top_quartile", color="subfield").update_traces(
    mode="lines+markers"
)
from plotly.subplots import make_subplots
import numpy as np
from plotly import graph_objects as go

lst = [{"secondary_y": True}]*4

fig = make_subplots(rows=40, cols=4,
                    specs=[lst for i in range(40)], 
                    subplot_titles = list(df['subfield'].unique())
                    )


for i, field in enumerate(list(df['subfield'].unique())):
    sub_df = df[df['subfield'] == field]
    fig.add_trace(
        go.Bar(x=sub_df['year'], y=sub_df['counts'], name=field),
        secondary_y=False, col = i - 4*(i // 4) + 1, row = i // 4 + 1
    )
    sub_df = df[df['subfield'] == field]
    fig.add_trace(
        go.Scatter(x=sub_df['year'], y=sub_df['top_quartile'], name=field),
        secondary_y=True, col = i - 4*(i // 4) + 1, row = i // 4 + 1
    )

    fig.update_yaxes(range=[0, 1], secondary_y=True, title_text="Proportion in Top Quartile", title_font=dict(size=8), col = i - 4*(i // 4) + 1, row = i // 4 + 1)
    if field in ['Medical Microbiology', 'Genetics', 'Clinical Sciences', 'Biochemistry And Cell Biology']:
        fig.update_yaxes(range=[0, 1500], secondary_y=False, title_text="Publication Counts", title_font=dict(size=8), col = i - 4*(i // 4) + 1, row = i // 4 + 1)
    else:
        fig.update_yaxes(range=[0, 500], secondary_y=False, title_text="Publication Counts", title_font=dict(size=8), col = i - 4*(i // 4) + 1, row = i // 4 + 1)

fig.update_layout(
    autosize=False,
    width=2000,
    height=8000,
    title='Publication Diversity by Sub-Field and Year',
)

fig.update_layout(showlegend=False)
fig.write_html("idr/adhoc/outputs/subfield_temporal_diversity.html")




